

    <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catsnack</title>
    <link rel="stylesheet" href="home.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css" />
    <link rel="stylesheet" href="cardapioComidas.css">
</head>

<body>

    <nav>
        <img class="logo" src="logo.PNG">
        <ul>
            <li>
                    <div class="home">
                    home
                    <div class="underline"></div>
                </div>
            </li>
        </ul>

        </ul>
        <ul>
            <li>
                <div class="menu">
                    menu
                    <div class="underline2"> </div>
                </div>
            </li>
        </ul>
        <ul>
            <li>

                <div class="aboutus">
                    about us
                    <div class="underline3"> </div>
                </div>
            </li>
        </ul>
        
        <ul>
            <li>
            <div class="logout"><a href="logout.php">Logout</a></div>
                    <div class="underline4"> </div>
            </li>
        </ul>

        <ul>
            <li>
                <div class="olausuario" style="left: 100%; position: relative;">
                <?php include 'ola_usuario.php';?>
                </div>
            </li>
        </ul>
    </nav>