# COMO FUNCIONA O GIT:

Imagina que o git é um espaço de trabalho aonde todo mundo mexe na mesma coisa em lugares diferentes, é isso que a gente vai usar pra
conseguir fazer o trabalho

# O QUE É UM COMMIT

Um commit é você enviar as alterações que você fez para o respositorio (site compartilhado)

# COMO USAR O GIT

Agora que o trabalho nem existe ainda, vão ser criados varios arquivos, como o home, o index, cada arquivo para cada parte do catsnack,
mas dps que você quiser fazer alterações em um arquivo já criado, você vai primeiro PUXAR as alterações feitas pelos outros no arquivo, para ai sim fazer quaisquer alterações no codigo

# O QUE ACONTECE SE EU NÃO PUXAR ANTES

Se você publicar uma versão desatualizada de um arquivo, todo o progresso do arquivo mais recente que já esta publicado vai ser apagado, isso pode acabar dando treta se não tiver o arquivo salvo em nenhum outro lugar

# QUANDO QUE EU VOU COMITAR ALGUMA COISA?

Só depois que você tiver >>>CERTEZA<<< de que você estiver editando o arquivo mais novo e tiver terminado as modificações

# COMO QUE EU SEI O QUE EU PRECISO FAZER NO TRABALHO?

Vai ta no grupo do wpp o que cada um precisa fazer e o prazo que cada um tem, se no final do trabalho alguem tiver que fazer a parte de outro pq o amiguinho não fez, dedura mesmo q se foda

# E SE EU NÃO SOUBER COMO FAZER?

Manda msg pro Dereck ou pro Isaac, eles vão tentar te dar um norte
